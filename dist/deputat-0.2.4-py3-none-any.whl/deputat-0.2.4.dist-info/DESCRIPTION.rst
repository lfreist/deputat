![Python 3.8](https://img.shields.io/badge/python-3.8-green.svg)
[![license](https://img.shields.io/github/license/mashape/apistatus.svg?maxAge=2592000)](https://github.com/leonfrcom/ErroRCalcS/blob/master/LICENSE)

# Deputat
Einfaches graphisches Benutzer Interface (GUI) zur vergabe von Schulstunden.
____
Aktuelle Version: 0.2.3 (beta)
____

# Installation
1. [Installiere python3](https://github.com/lfreist/deputat/blob/master/infos/install_python.md)
2. Installiere deputat über pythons packetmanager [PyPi](https://pypi.org/). Gebe dazu
in der Konsole ```python3 -m pip install deputat``` ein
3. Starte deputat über ```python3 -m app```


