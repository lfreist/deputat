try:
    from deputat.GUI import maingui
except ImportError:
    from GUI import maingui


def run_gui():
    maingui.run()


if __name__ == '__main__':
    run_gui()