"""
TODO: - complete menubar
      - functionality to remove/edit teachers and classes
"""

import run

if __name__ == '__main__':
    run.run_gui()
