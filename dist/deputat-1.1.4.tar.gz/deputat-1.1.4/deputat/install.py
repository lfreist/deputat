from deputat import settings

def install():
    platform = settings.get_os()
